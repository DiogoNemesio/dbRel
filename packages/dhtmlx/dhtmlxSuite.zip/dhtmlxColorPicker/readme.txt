dhtmlxColorPicker v.3.5 Standard edition build 120822

(c) DHTMLX Ltd. 