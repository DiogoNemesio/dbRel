The next samples require php suppport
	01_initialization_loading/05_loading_mysql.html 
	01_initialization_loading/09_connector_options.html
	02_customization/shared_events
	03_extensions/01_recurring_events.html 
	03_extensions/17_connector_units.html 
	04_export/ - all samples in this folder
	
To check them you need to 
	- import related sql dump from common folder
	- configure the connection settings in common/config.php
	
04_export/04_pdf.html configured to use online service. 
You can reconfigure it, to work locally, for it separate package is required - "scheduler-to-pdf", 
which can be obtained by the next link  http://www.dhtmlx.com/blog/?p=553

